import{a1 as a,an as t}from"./index.cc269242.js";const s=a(t);export{s as C};
